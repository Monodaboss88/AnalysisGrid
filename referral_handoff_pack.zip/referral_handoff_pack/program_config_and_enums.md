# Program Config + Enums (Firestore)

## Program Config Document
**Path:** `referralProgramConfig/current`

### Fields (authoritative rules)
**Identity**
- programName: "Referral Rewards v1"
- effectiveAt: <timestamp>
- currency: "USD"

**Membership**
- membershipDuesCents: 25000
- billingCycleDays: 30

**Coverage Rules**
- coverageReferralTarget: 5
- coverageRateCents: 5000
- coverageAppliesTo: "INVOICE_CREDIT_ONLY"
- coverageMaxCents: 25000

**Post-Coverage Payout Rules**
- postCoverageBaseRateCents: 2500
- postCoverageBoosterThreshold: 12
- postCoverageBoosterRateCents: 5000
- boosterAppliesTo: "EXTRA_ONLY"

**Payout Policy**
- payoutFrequency: "MONTHLY"
- payoutRunDayOfMonth: 15
- payoutRunTimeET: "09:00"
- earningsHoldbackDays: 30
- minPayoutCents: 5000
- payoutMethodPolicy: "CASH_PAYOUT"
- carryoverEnabled: true
- carryoverField: "members.payoutCarryoverCents"

**Access / Grace**
- graceHours: 24

**Eligibility Policy**
- eligibilityRequiresMemberStatus: "ACTIVE"
- eligibilityRequiresBillingCurrent: true
- eligibilityEvaluationPoint: "REFERRER_CYCLE_CLOSE"
- graceCountsAsCurrentForReferrals: false

**Anti-Abuse (recommended flags)**
- blockSelfReferral: true
- lockReferrerAfterActivation: true
- reversalOnChargebackEnabled: true
- reversalWindowDays: 30

---

## Standard Status Enums

### members.status
- ACTIVE
- PAST_DUE
- SUSPENDED
- CANCELLED

### members.accessState
- ACTIVE
- GRACE
- SUSPENDED

### referrals.status
- PENDING
- ACTIVE
- INACTIVE

### billingAccounts.status
- ACTIVE
- PAST_DUE
- SUSPENDED
- CANCELLED

### referralEarnings.status
- CALCULATED
- READY
- PAID
- HELD
- REVERSED

### payoutLedger.status
- QUEUED
- SENT
- SETTLED
- FAILED
- REVERSED
