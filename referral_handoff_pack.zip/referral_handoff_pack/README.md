# Referral + Billing + Payouts (Firebase) — Handoff Pack

This folder contains:
- `handoff_spec.md` — the full build spec (Firestore schema + functions + UI + security boundaries)
- `claude_prompt.txt` — copy/paste prompt template for Claude (or other LLM) to generate implementation artifacts
- `program_config_and_enums.md` — the Firestore config doc and all standardized status enums
- `security_boundary_spec.md` — concise read/write boundaries per collection (member/admin/server)
- `system_flow_diagram.txt` — one-page ASCII trigger diagram for quick alignment

Key locked policy:
- Membership: $250 every 30 days (rolling).
- Renewal failure: 24-hour GRACE, then SUSPENDED until paid.
- Referral:
  - First 5 active referrals cover dues ($50 each → invoice credit up to $250).
  - Extras beyond 5 accrue cash: $25 each, but if total active referrals N ≥ 12 then extras pay $50.
  - Booster applies to extras only.
- Payout:
  - Run monthly on the 15th at 9:00 AM ET.
  - 30-day earnings holdback (must mature).
  - Minimum payout $50; otherwise carryover.
- Collect renewals with Authorize.Net ARB; pay out via Dwolla ACH (Plaid IAV + micro-deposit fallback).
