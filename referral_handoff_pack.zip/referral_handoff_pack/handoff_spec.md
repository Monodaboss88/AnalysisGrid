# Referral + Billing + Payouts (Firebase) — Final Build Spec

## Locked Policy
- Membership: $250 due every 30 days (rolling cycle).
- Renewal failure: 24-hour GRACE, then SUSPENDED access until paid.
- Referral value at referrer evaluation (cycle close):
  - First 5 eligible active referrals cover dues: $50 each → invoice credit up to $250.
  - Extra referrals beyond 5 accrue cash: $25 each.
  - Booster: if total eligible active referrals N ≥ 12, extras accrue at $50 each.
  - Booster applies to extras only.
- Eligibility: referred member must be ACTIVE and billing-current at evaluation point; GRACE does NOT count as current for referral eligibility.
- Payout: monthly batch on 15th @ 9:00 AM ET; earnings must mature 30 days; minimum payout $50; otherwise carryover rolls forward.
- Payments in: Authorize.Net ARB for renewals.
- Payouts out: Dwolla ACH; bank verification via Plaid IAV with micro-deposit fallback.

---

## Firestore Collections + Fields

### `referralProgramConfig/current`
See `program_config_and_enums.md`.

### `members/{memberId}`
- status: ACTIVE | PAST_DUE | SUSPENDED | CANCELLED
- accessState: ACTIVE | GRACE | SUSPENDED
- referralCode (unique)
- payoutHold (bool)
- payoutCarryoverCents (number) **server-only write**
- payoutProfileId (ref)
- createdAt, updatedAt

### `billingAccounts/{memberId}`
- duesCents: 25000
- cycleLengthDays: 30
- cycleStartAt, cycleEndAt
- nextDueAt (=cycleEndAt)
- currentThroughAt
- isCurrent (bool)
- paymentFailedAt (nullable)
- graceEndsAt (nullable; paymentFailedAt + 24h)
- status: ACTIVE | PAST_DUE | SUSPENDED | CANCELLED
- authorizeNet: { customerProfileId, paymentProfileId, subscriptionId }
- updatedAt

### `referrals/{referredMemberId}` (deterministic ID)
- referredMemberId (same as doc id)
- referrerMemberId
- referralCodeUsed
- status: PENDING | ACTIVE | INACTIVE
- createdAt, activatedAt, deactivatedAt
- deactivationReason

### `payments/{paymentId}`
- memberId
- amountCents
- status: POSTED | VOIDED | CHARGEBACK
- postedAt
- notes

### `referralEarnings/{cycleKey_referrerId}`
- referrerMemberId
- cycleStartAt, cycleEndAt
- activeReferralCount (N)
- coverageCount, extraCount
- boosterActive (bool)
- extraRateCents (2500 or 5000)
- coverageCreditCents
- invoiceCreditAppliedCents
- extraEarningsCents
- earnedAt
- maturesAt (=earnedAt + 30d)
- carryoverInCents
- payoutEligibleCents (matured portion)
- status: CALCULATED | READY | PAID | HELD | REVERSED
- createdAt

### `payoutProfiles/{payoutProfileId}`
- memberId (unique)
- provider: DWOLLA
- method: ACH
- verificationStatus: PENDING | VERIFIED
- dwollaCustomerId
- dwollaFundingSourceId
- destinationLast4 (optional)
- createdAt, updatedAt

### `payoutLedger/{payoutId}`
- memberId
- provider: DWOLLA
- amountCents
- includedEarningsKeys (array)
- status: QUEUED | SENT | SETTLED | FAILED | REVERSED
- dwollaTransferId (nullable)
- createdAt, sentAt, settledAt
- failureReason (nullable)

### `auditLog/{logId}` (server-write only)
- adminId
- actionType
- targetPath
- before, after (or diff)
- reason
- createdAt

---

## Core Calculations

### Eligibility at evaluation point (referrer cycle close)
A referral counts if:
- referrals.status == ACTIVE
- referred member members.status == ACTIVE
- referred member billingAccounts.currentThroughAt >= referrer billingAccounts.cycleEndAt
- referred member is not in GRACE for referral eligibility

### Earnings Math
Let N = eligible active referrals.
- CoverageCount = min(N, 5)
- CoverageCreditCents = CoverageCount * 5000
- InvoiceCreditAppliedCents = min(CoverageCreditCents, 25000)
- ExtraCount = max(0, N - 5)
- ExtraRateCents = (N >= 12) ? 5000 : 2500
- ExtraEarningsCents = ExtraCount * ExtraRateCents
- Add ExtraEarningsCents to members.payoutCarryoverCents
- Write referralEarnings with earnedAt and maturesAt

---

## Cloud Functions (Responsibilities)

### 1) `authorizeNetWebhookHandler`
- Verify webhook
- Map event to member via subscriptionId/customerProfileId
- On success:
  - billingAccounts.isCurrent=true
  - extend cycleStartAt/cycleEndAt by 30 days
  - currentThroughAt=newEnd
  - clear paymentFailedAt/graceEndsAt
  - members.accessState=ACTIVE
- On failure:
  - billingAccounts.isCurrent=false
  - paymentFailedAt=now
  - graceEndsAt=now+24h
  - members.accessState=GRACE

### 2) `graceExpirationEnforcer` (scheduled hourly)
- For accounts graceEndsAt<=now and still not current:
  - members.accessState=SUSPENDED
  - billingAccounts.status=SUSPENDED (or PAST_DUE + access suspended)

### 3) `applyReferralCodeOnSignup` (callable)
- Validate referralCode
- Prevent self-referral
- Create referrals/{referredId}=PENDING

### 4) `activateReferralIfEligible`
- When referred becomes current:
  - referrals/{referredId}: PENDING -> ACTIVE

### 5) `cycleCloseoutAndEarnings` (scheduled daily/hourly backstop)
- Detect cycle close and compute earnings snapshot at cycleEndAt for each referrer.
- Update carryover and write referralEarnings.

### 6) `buildPayoutBatch` (scheduled monthly on 15th @ 9:00 AM ET)
- Select members with:
  - payoutHold=false
  - payoutProfile VERIFIED
  - matured eligible balance >= $50
- Create payoutLedger=QUEUED and reduce carryover by paid matured amount.

### 7) `executeQueuedPayouts`
- For each QUEUED payout:
  - create Dwolla transfer from business funding source -> member funding source
  - store dwollaTransferId
  - mark SENT

### 8) `dwollaWebhookHandler`
- Verify webhook
- Update payoutLedger statuses to SETTLED/FAILED
- On FAILED: return amount to carryover; admin flag; audit log

Idempotency required on both webhook handlers and payout execution.

---

## UI Requirements

### Member
- Billing status (ACTIVE/GRACE countdown/SUSPENDED) + payment method update
- Referral dashboard: code, N, coverage progress, booster flag, carryover, next payout date
- Payout setup: connect bank via Plaid IAV; fallback micro-deposits; show verification status

### Admin
- Member lookup + holds + status
- Billing console (manual payments/voids)
- Referral console (override status with reason)
- Earnings viewer (cycle + maturity)
- Payout queue (15th batch)
- Payout ledger (settled/failed)
- Audit log

---

## Security Boundaries
See `security_boundary_spec.md`. All financial mutations are Cloud-Function-only.
