# Security Boundary Spec (Firestore)

## Roles
- member (default)
- admin
- super_admin (optional)

## Principles
- Members can read within scope; cannot write any financial or eligibility-critical fields.
- All money/eligibility writes are Cloud-Function-only.
- Admin changes require reason + audit log.

## Collection Rules

### members/{memberId}
- Member: read own doc
- Member: write only non-financial profile fields
- Admin: read/write (status/access/holds) with audit
- Server: write carryover + computed fields

### referrals/{referredMemberId}
- Member: read as referrer (query) and as referred (doc by id)
- Member: no direct writes (recommended)
- Admin: can override status w/ audit
- Server: create pending, activate/inactivate

### billingAccounts/{memberId}
- Member: read own doc
- Member: no writes
- Admin: read; optional restricted writes
- Server: full control

### payments/{paymentId}
- Member: read own payments
- Member: no writes (recommended)
- Admin: create/void/chargeback with audit
- Server: reconciliation updates

### referralEarnings/{earningId}
- Member: read own earnings
- Member: no writes
- Admin: read; optional dispute flags
- Server: create/update calculations + maturity

### payoutProfiles/{payoutProfileId}
- Member: read own profile
- Member: write only onboarding request fields (token refs), never verification status
- Admin: set verification/holds
- Server: create Dwolla customer + funding source ids

### payoutLedger/{payoutId}
- Member: read own payouts
- Member: no writes
- Admin: read; no direct writes preferred
- Server: create/advance status

### auditLog/{logId}
- Member: no access
- Admin: read access
- Server: write only
